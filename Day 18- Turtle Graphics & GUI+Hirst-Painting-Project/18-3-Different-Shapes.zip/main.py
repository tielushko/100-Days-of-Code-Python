import turtle as t
import random

tim = t.Turtle()

########### Challenge 3 - Draw Shapes ########

def draw_figure(num_sides):
    angle_of_turn = 360 / num_sides
    for i in range(num_sides):
        tim.forward(100)
        tim.right(angle_of_turn)

    
for i in range(3, 11):
    tim.color('navy')
    draw_figure(i)