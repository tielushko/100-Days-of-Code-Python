import turtle as t
import random

tim = t.Turtle()

########### Challenge 4 - Random Walk ########
colours = ["CornflowerBlue", "DarkOrchid", "IndianRed", "DeepSkyBlue", "LightSeaGreen", "wheat", "SlateGray", "SeaGreen"]

tim.turtlesize(3,3,3)
tim.pensize(6)
tim.speed('fastest')
t.colormode(255)

def random_color():
    R = random.randint(0, 255)
    G = random.randint(0, 255)
    B = random.randint(0, 255)
    return (R,G,B)

def random_step():
    color = random_color()
    turn_multiplier = random.randint(0,4)
    tim.color(color)    
    tim.left(90 * turn_multiplier)
    tim.forward(20)

for i in range(1000):
    random_step()