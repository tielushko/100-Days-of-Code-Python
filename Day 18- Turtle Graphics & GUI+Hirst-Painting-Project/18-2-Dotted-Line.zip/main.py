import turtle as t

tim = t.Turtle()

########### Challenge 2 - Draw a Dashed Line ########
def draw_solid_line():
    tim.forward(20)
    tim.penup()

def draw_empty_line():
    tim.forward(20)
    tim.pendown()

def draw_dashed_line():
    draw_solid_line()
    draw_empty_line()

for i in range(4):
    draw_dashed_line()